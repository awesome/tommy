from setuptools import setup

setup(name='tommy',
      version='0.1',
      description='Modular virtual assistan',
      url='https://github.com/amark97/tommy',
      author='amark, SoAwesomeMan',
      author_email='alexandre.markiewicz.1997@gmail.com, callme@1800AWESO.ME',
      license='MIT',
      packages=['tommy'],
      zip_safe=False)
